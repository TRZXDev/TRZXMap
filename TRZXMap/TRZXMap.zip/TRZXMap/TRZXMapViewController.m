//
//  TRZXMapViewController.m
//  TRZX
//
//  Created by Rhino on 2016/12/20.
//  Copyright © 2016年 Tiancaila. All rights reserved.
//

#import "TRZXMapViewController.h"
#import "MAUserHeadAnnotationView.h"
#import "MapCardCollectionView.h"
#import "MapUser.h"
#import "TRZXKit.h"
#import "UIImageView+AFNetworking.h"

@interface TRZXMapViewController ()<MAMapViewDelegate,AMapSearchDelegate>
                                    

@property (nonatomic,strong) AMapSearchAPI    *search;
@property (nonatomic,strong) MAMapView        *mapView;

@property (nonatomic,strong)MAUserHeadAnnotationView *currentAnnotationView;
@property (nonatomic,strong)MapCardCollectionView *mapCardCollectionView;
@property (nonatomic,strong)UIButton *resetBtn;
@property (nonatomic,assign)BOOL isMaploadingSuccess;


@property (nonatomic,strong)NSArray *tradeIds;
@property (nonatomic,strong)NSArray *stageIds;
@property (nonatomic, strong) NSMutableArray *annotationArray;

@property (nonatomic, strong) NSArray<MAAnnotationView *> *maAnnotationViewsArray;

@property (nonatomic,strong)NSString *expertsPositionId;

@property (nonatomic,assign)BOOL isLoadData;
@property (nonatomic,assign)BOOL isOneData;



@end

@implementation TRZXMapViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    _annotationArray = [[NSMutableArray alloc] init];
    _currentCity =[[City alloc] init];
    _tempCity =[[City alloc] init];


    if (self.mapType == TRZXMapType_Expert) {
       self.view.frame = CGRectMake(0, MapheaderViewbutton, self.view.width, self.view.height-64-MapheaderViewbutton);
    }else{
       self.view.frame = CGRectMake(0, 0, self.view.width, self.view.height-64);
    }
    [self addMap];
    [self addMapBottomView];




}


-(void)setCurrentCity:(City *)currentCity{
    _currentCity = currentCity;
}


-(void)setTempCity:(City *)tempCity{
    _tempCity = tempCity;


    // 地图加载完毕移动到用户中心点位置
    [self.mapView setCenterCoordinate:CLLocationCoordinate2DMake([_tempCity.latitude floatValue], [_tempCity.longitude floatValue]) animated:NO];
    [self.mapView setZoomLevel:10 animated:NO];// 移动到2级别
    [self request_map_places_findNearByInvWith:_currentCity tempCity:_tempCity zoomLevel:_mapView.zoomLevel tradeId:_tradeIds stageId:_stageIds];



}

//领域id数组  //阶段id数组
-(void)setTradeIds:(NSArray*)tradeIds stageIds:(NSArray *)stageIds{

    _tradeIds = tradeIds;
    _stageIds = stageIds;

    [self hiddenMapCardCollectionView];

    if (_currentCity&&_tempCity) {
        [self request_map_places_findNearByInvWith:_currentCity tempCity:_tempCity zoomLevel:_mapView.zoomLevel tradeId:_tradeIds stageId:_stageIds];
    }
}

// 专家地图分类筛选
-(void)setExpertsPositionId:(NSString*)mid{

    _expertsPositionId = mid;
    [self hiddenMapCardCollectionView];

    if (_currentCity&&_tempCity) {
        [self request_map_places_findNearByInvWith:_currentCity tempCity:_tempCity zoomLevel:_mapView.zoomLevel tradeId:_tradeIds stageId:_stageIds];
    }




}


// 用户数据转换成 MAPointAnnotations
-(NSMutableArray*)getMAPointAnnotation:(NSMutableArray*)users{
    NSMutableArray *array = [[NSMutableArray alloc]init];
    for (int i=0;i<users.count;i++) {
        MapUser *model = users[i];
        MAClusterPointAnnotation *clusterPointAnnotation = [[MAClusterPointAnnotation alloc]init];

        CLLocationCoordinate2D coords = CLLocationCoordinate2DMake([model.latitude floatValue],[model.longitude floatValue]);//纬度，经度
        clusterPointAnnotation.coordinate = coords;
        clusterPointAnnotation.model = model;
        clusterPointAnnotation.index = i;
        [array addObject:clusterPointAnnotation];




    }
    return array;
}


-(void)request_map_places_findNearByInvWith:(City*)currentCity tempCity:(City*)tempCity zoomLevel:(CGFloat)zoomLevel tradeId:(NSArray*)tradeId  stageId:(NSArray*)stageId{


    NSDictionary * userCoordinate = @{@"latitude":currentCity.latitude,@"longitude":currentCity.longitude};  //当前用户所在位置
    NSDictionary * coordinate = @{@"latitude":tempCity.latitude,@"longitude":tempCity.longitude};// 当前位置之外的位置
    NSMutableDictionary *params = [[NSMutableDictionary alloc]initWithObjectsAndKeys:userCoordinate, @"userCoordinate", coordinate, @"coordinate", nil];

    NSInteger zoomLevelInt = [[NSString stringWithFormat:@"%0.f",zoomLevel] integerValue];

    [params setObject: [NSString stringWithFormat:@"%0.f",zoomLevel] forKey:@"level"];

    if (tradeId.count>0) {
        [params setObject:tradeId forKey:@"tradeId"];
    }
    if (stageId.count>0) {
        [params setObject:stageId forKey:@"stageId"];
    }

    if (self.mapType == TRZXMapType_Expert) {
        [params setObject:@"/api/map/places/findNearByExpert" forKey:@"path"];
        if (_expertsPositionId.length>0) {
            [params setObject:_expertsPositionId forKey:@"userTitleId"];
        }
    }else if(self.mapType == TRZXMapType_Stockholder){
        [params setObject:@"/api/map/places/findNearByShare" forKey:@"path"];
    }else{
        [params setObject:@"/api/map/places/findNearByInv" forKey:@"path"];
    }





//
//    [[Kipo_NetAPIManager sharedManager] request_map_places_findNearByInvWith:params Block:^(id data, NSError *error) {
//
//
//        [_mapView removeAnnotations:_annotationArray];
//        [_annotationArray removeAllObjects];
//
//
//
//
//        
//
//        _annotationArray = [self getMAPointAnnotation:data];
//        // 给地图添加标注
//        [self.mapView addAnnotations:_annotationArray];
//        _mapCardCollectionView.mapCards = [NSMutableArray arrayWithArray:_annotationArray];
//
//
//
//        if (!self.isOneData) {
//            self.isOneData = !self.isOneData;
//            _tempCity = tempCity;
//            _currentCity = currentCity;
//
//            if (_annotationArray.count>0) {
//                MAClusterPointAnnotation *annotation = _annotationArray[0];
//                _currentAnnotationView = (MAUserHeadAnnotationView *)[self.mapView viewForAnnotation:annotation];
//                [_currentAnnotationView setAnimation0];
//                [_mapView selectAnnotation:_currentAnnotationView.annotation animated:YES];
//                [self showMapCardCollectionView];// 显示卡片View
//            }
//        }
//
//        
//    }];
//    

    
}




#pragma mark - UI

- (void)addMap
{
    [self.view addSubview:self.mapView];
    //初始化检索对象 用于检索行政区域
    _search = [[AMapSearchAPI alloc] init];
    _search.delegate = self;
}
- (void)addMapBottomView
{


    __weak TRZXMapViewController *weakSelf = self;

    CGRect frame;
    if (self.mapType == TRZXMapType_Expert) {
        frame = CGRectMake(0, self.view.height, self.view.width, MapExpertBottomHeight);

    }else if(self.mapType == TRZXMapType_Stockholder){
        frame = CGRectMake(0, self.view.height, self.view.width, MapStockBottomHeight);
    }else{
        frame = CGRectMake(0, self.view.height, self.view.width, MapInvistorBottomHeight);

    }



    _mapCardCollectionView = [[MapCardCollectionView alloc]initWithFrame:frame type:self.mapType];
    
    _mapCardCollectionView.mapCardCollectionViewBlock = ^(MAClusterPointAnnotation *annotation) {



        if (self.mapType == TRZXMapType_Expert) {

//            ConsultingDetailsViewController *  oneToOneList = [[ConsultingDetailsViewController alloc]init];
//            oneToOneList.mid = annotation.model.userId;
//            [weakSelf.navigationController pushViewController:oneToOneList animated:true];

        }else if(self.mapType == TRZXMapType_Stockholder){


//            if (![NSObject showCertificationTip:self]) {
//                PersonalInformationVC * studentPersonal=[[PersonalInformationVC alloc]init];
//                studentPersonal.midStrr = annotation.model.userId;
//                studentPersonal.otherStr = @"1";
//                [self.navigationController pushViewController:studentPersonal animated:true];
//                
//            }
        }

    };






    _mapCardCollectionView.scrollViewDidEndDeceleratingPagBlock = ^(NSInteger index){
        MAClusterPointAnnotation *annotation = weakSelf.annotationArray[index];
        MAUserHeadAnnotationView *view = (MAUserHeadAnnotationView *)[weakSelf.mapView viewForAnnotation:annotation];
        [weakSelf scrollViewDidEndDecelerating:view];
        
        
        
        
    };

    [self.view addSubview:_mapCardCollectionView];
    




    [self.view addSubview:self.resetBtn];
    CGFloat width= 40;
    CGFloat height = 40;
    CGFloat gap = 8;
//    [self.resetBtn mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.bottom.equalTo(sfself.mapCardCollectionView.mas_top).offset(-gap);
//        make.left.equalTo(sfself.mapCardCollectionView.mas_left).offset(gap);
//        make.height.equalTo(@(width));
//        make.width.equalTo(@(height));
//    }];
}





//计算屏幕范围
- (NSString *)returnRadious
{
    //1.获得地图左上角 和地图右下角的坐标
    //当前屏幕显示范围的经纬度
    
    CLLocationCoordinate2D top = [_mapView convertPoint:CGPointMake(0, MapheaderViewbutton) toCoordinateFromView:self.mapView];
    CLLocationCoordinate2D bottom = [_mapView convertPoint:CGPointMake(self.mapView.frame.size.height-MapheaderViewbutton, _mapView.frame.size.width) toCoordinateFromView:_mapView];;
    //2.将两个经纬度点转成投影点
    MAMapPoint point1 = MAMapPointForCoordinate(top);
    MAMapPoint point2 = MAMapPointForCoordinate(bottom);
    //3.计算距离
    CLLocationDistance distance = MAMetersBetweenMapPoints(point1,point2);
    return [NSString stringWithFormat:@"%f",distance];
}










#pragma mark - 地图加载完毕后调用--计算距离
- (void)mapInitComplete:(MAMapView *)mapView
{

    _isMaploadingSuccess = !_isMaploadingSuccess;


    _currentCity.latitude = [NSString stringWithFormat:@"%f",_mapView.userLocation.coordinate.latitude];
    _currentCity.longitude = [NSString stringWithFormat:@"%f",_mapView.userLocation.coordinate.longitude];



    if (self.mapInitCompleteBlock) {
        self.mapInitCompleteBlock(mapView,_currentCity,_currentCity);
    }

    NSLog(@">>>>>>>>>>>>>>>>>地图加载完毕后调用=latitude=%@=latitude=%@",_currentCity.latitude,_currentCity.longitude);

    // 地图加载完毕移动到用户中心点位置
    if (_mapView.userLocation.location.coordinate.latitude || _mapView.userLocation.location.coordinate.longitude) {
        [self.mapView setCenterCoordinate:CLLocationCoordinate2DMake(_mapView.userLocation.location.coordinate.latitude, _mapView.userLocation.location.coordinate.longitude) animated:NO];
    }

    dispatch_time_t delayTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5/*延迟执行时间*/ * NSEC_PER_SEC));
    dispatch_after(delayTime, dispatch_get_main_queue(), ^{
        [self.mapView setZoomLevel:16 animated:YES];// 移动到16级别

    });


    
    
    
}

#pragma mark - MAMapViewDelegate
/**
 *  地图将要发生移动时调用此接口
 *
 *  @param mapView       地图view
 *  @param wasUserAction 标识是否是用户动作
 */
- (void)mapView:(MAMapView *)mapView mapWillMoveByUser:(BOOL)wasUserAction{
    [self.currentAnnotationView closeAnimation];
    if (_mapCardCollectionView.mapCards.count>0) {
        [self hiddenMapCardCollectionView];
    }

}



/**
 *  地图移动结束后调用此接口
 *
 *  @param mapView       地图view
 *  @param wasUserAction 标识是否是用户动作
 */
- (void)mapView:(MAMapView *)mapView mapDidMoveByUser:(BOOL)wasUserAction
{

    NSLog(@">>>>>>>>>>>>>>>>>地图移动结束后调用此接口=%f",mapView.zoomLevel);


    AMapReGeocodeSearchRequest *regeo = [[AMapReGeocodeSearchRequest alloc] init];
    regeo.location = [AMapGeoPoint locationWithLatitude:_mapView.centerCoordinate.latitude longitude:_mapView.centerCoordinate.longitude];
    regeo.requireExtension =YES;
    [_search AMapReGoecodeSearch:regeo];


    if (wasUserAction) {
        _tempCity.latitude = [NSString stringWithFormat:@"%f",_mapView.centerCoordinate.latitude];
        _tempCity.longitude = [NSString stringWithFormat:@"%f",_mapView.centerCoordinate.longitude];
        [self request_map_places_findNearByInvWith:_currentCity tempCity:_tempCity zoomLevel:_mapView.zoomLevel tradeId:_tradeIds stageId:_stageIds];

    }




}




/* 逆地理编码回调. */
- (void)onReGeocodeSearchDone:(AMapReGeocodeSearchRequest *)request response:(AMapReGeocodeSearchResponse *)response
{

    if (response.regeocode !=nil )
    {

        NSLog(@"反向地理编码回调city:%@",response.regeocode.addressComponent.city);
        NSLog(@"反向地理编码回调province:%@",response.regeocode.addressComponent.province);

        City *city = [[City alloc]init];
        city.latitude = [NSString stringWithFormat:@"%f",request.location.latitude];
        city.longitude = [NSString stringWithFormat:@"%f",request.location.longitude];
        city.citycode = response.regeocode.addressComponent.citycode;

        if (response.regeocode.addressComponent.city.length>0) {
            city.name = response.regeocode.addressComponent.city;
        }else{
            city.name = response.regeocode.addressComponent.province;
        }

        if (self.mapInitCompleteBlock) {
            if (self.mapInitCompleteBlock) {
                self.mapInitCompleteBlock(_mapView,_currentCity,city);
            }
        }

    }
    
}



/**
 *  地图将要发生缩放时调用此接口
 *
 *  @param mapView       地图view
 *  @param wasUserAction 标识是否是用户动作
 */
- (void)mapView:(MAMapView *)mapView mapWillZoomByUser:(BOOL)wasUserAction{

    [self.currentAnnotationView closeAnimation];
    if (_mapCardCollectionView.mapCards.count>0) {
        [self hiddenMapCardCollectionView];
    }


}
/**
 *  地图缩放结束后调用此接口
 *
 *  @param mapView       地图view
 *  @param wasUserAction 标识是否是用户动作
 */
- (void)mapView:(MAMapView *)mapView mapDidZoomByUser:(BOOL)wasUserAction
{

    NSLog(@">>>>>>>>>>>>>>>>>地图缩放结束后调用此接口=%f",mapView.zoomLevel);


    if (!_isLoadData) {
        _isLoadData = !_isLoadData;
    }else{
        _tempCity.latitude = [NSString stringWithFormat:@"%f",_mapView.centerCoordinate.latitude];
        _tempCity.longitude = [NSString stringWithFormat:@"%f",_mapView.centerCoordinate.longitude];
        [self request_map_places_findNearByInvWith:_currentCity tempCity:_tempCity zoomLevel:_mapView.zoomLevel tradeId:_tradeIds stageId:_stageIds];


    }


}







/**
 * @brief 单击地图回调，返回经纬度
 * @param mapView 地图View
 * @param coordinate 经纬度
 */
- (void)mapView:(MAMapView *)mapView didSingleTappedAtCoordinate:(CLLocationCoordinate2D)coordinate
{
    if (self.isMaploadingSuccess) {
        [self.currentAnnotationView closeAnimation];
        [self hiddenMapCardCollectionView];// 显示卡片View
    }
    
}



- (MAAnnotationView *)mapView:(MAMapView *)mapView viewForAnnotation:(id<MAAnnotation>)annotation
{
    if ([annotation isKindOfClass:[MAClusterPointAnnotation class]]) {

        static NSString *pointReuseIndetifier = @"pointReuseIndetifier";
        MAUserHeadAnnotationView *annotationView = (MAUserHeadAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:pointReuseIndetifier];
        if (annotationView == nil){
            annotationView = [[MAUserHeadAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:pointReuseIndetifier];
        }
        annotationView.clusterAnnotation = (MAClusterPointAnnotation *)annotation;


        if (annotationView.clusterAnnotation.model.kcount>0) {
            annotationView.headImageView.hidden = YES;
            annotationView.bgImageView.image = [UIImage imageNamed:@"未选中"];
            annotationView.titleLabel.text =   annotationView.clusterAnnotation.model.kcount;
        }else{
            annotationView.headImageView.hidden = NO;


            [annotationView.headImageView setImageWithURL:[NSURL URLWithString:annotationView.clusterAnnotation.model.photo.length>0?annotationView.clusterAnnotation.model.photo:@""]];

        }


        annotationView.maUserHeadAnnotationViewBlock = ^(MAUserHeadAnnotationView* view){
            [self didSelectItemAtIndexPath:view];
        };

        
        return annotationView;
    }
    
    return nil;
    
}


-(void)didSelectItemAtIndexPath:(MAUserHeadAnnotationView*)view{


    MAClusterPointAnnotation *clusterAnnotation = (MAClusterPointAnnotation *)view.annotation;



    if ([clusterAnnotation.model.level isEqualToString:@"adcode"]) {


        if(_mapView.zoomLevel+1>=10){ // 12-10

            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                //                        [self.mapView setCenterCoordinate:CLLocationCoordinate2DMake(self.mapView.userLocation.location.coordinate.latitude, self.mapView.userLocation.location.coordinate.longitude) animated:YES];


                [self.mapView setCenterCoordinate:CLLocationCoordinate2DMake([clusterAnnotation.model.localLatitude floatValue], [clusterAnnotation.model.locaLongitude floatValue]) animated:YES];
                [self.mapView setZoomLevel:14 animated:YES];
                [self.mapView setMapStatus:self.mapView.getMapStatus animated:YES duration:0.35];
                
            });

        }else  { // 9-3
            
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{

                [self.mapView setCenterCoordinate:CLLocationCoordinate2DMake([clusterAnnotation.model.localLatitude floatValue], [clusterAnnotation.model.locaLongitude floatValue]) animated:YES];


                [self.mapView setZoomLevel:9 animated:YES];
                [self.mapView setMapStatus:self.mapView.getMapStatus animated:YES duration:0.35];
                self.isOneData = NO;
            });

        }




    }else if ([clusterAnnotation.model.level isEqualToString:@"citycode"]){



        if(_mapView.zoomLevel+1>=10){ // 12-10

            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                
                
                [self.mapView setCenterCoordinate:CLLocationCoordinate2DMake([clusterAnnotation.model.latitude floatValue], [clusterAnnotation.model.longitude floatValue]) animated:YES];

                [self.mapView setZoomLevel:14 animated:YES];
                [self.mapView setMapStatus:self.mapView.getMapStatus animated:YES duration:0.35];
                 self.isOneData = NO;
            });

        }else  { // 9-3

            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                
                CGFloat bias_longitude = fabs([clusterAnnotation.model.longitude floatValue] - self.mapView.userLocation.coordinate.longitude);
                CGFloat bias_latitude =  fabs([clusterAnnotation.model.latitude floatValue] - self.mapView.userLocation.coordinate.latitude);
                CGFloat laongitude = bias_longitude < 0.5f ? self.mapView.userLocation.coordinate.longitude : [clusterAnnotation.model.longitude floatValue];
                CGFloat latitude = bias_latitude < 0.5f ? self.mapView.userLocation.coordinate.latitude : [clusterAnnotation.model.latitude floatValue];
                [self.mapView setCenterCoordinate:CLLocationCoordinate2DMake(latitude, laongitude) animated:YES];
                
                [self.mapView setZoomLevel:14 animated:YES];
                [self.mapView setMapStatus:self.mapView.getMapStatus animated:YES duration:0.35];
                self.isOneData = NO;
            });

        }



    }else{


        [self scrollViewDidEndDecelerating:view];
        [self showMapCardCollectionView];// 显示卡片View
        [_mapCardCollectionView.collectionView scrollToItemAtIndexPath:[NSIndexPath indexPathForItem:clusterAnnotation.index inSection:0]atScrollPosition:UICollectionViewScrollPositionNone animated:NO];


    }



}





#pragma mark - 当已经添加大头针视图后调用(还没有显示在地图上)该方法可以用来设置自定义动画
-(void)mapView:(MAMapView *)mapView didAddAnnotationViews:(NSArray<MAAnnotationView *> *)views{


//
//        for (int i=0; i<views.count; i++) {
//
//            MAAnnotationView *anv = views[i];
//            // 排除定位的大头针
//            if ([anv.annotation isKindOfClass:[MAUserLocation class]]) {
//                return;
//            }
//
//            if (i==0&&!_isOneData) {
//
//                _isOneData = !_isOneData;
//
//                _currentAnnotationView = (MAUserHeadAnnotationView *)anv;
//                [_currentAnnotationView setAnimation0];
//                [_mapView selectAnnotation:_currentAnnotationView.annotation animated:YES];
//
//                [self showMapCardCollectionView];// 显示卡片View
//            }
//
//
////            CGRect targetRect = anv.frame;
////            // 修改位置
////            anv.frame = CGRectMake(targetRect.origin.x, 0, targetRect.size.width, targetRect.size.height);
////            [UIView animateWithDuration:1 animations:^{
////                anv.frame = targetRect;
////            }];
//        }
//
//
//
//
//    }


}

#pragma mark - EventHandle


- (void)transToPersonalWithMid:(NSString *)mid
{
    
//    if (![NSObject showCertificationTip:self]) {
//        
//        PersonalInformationVC * studentPersonal=[[PersonalInformationVC alloc]init];
//        studentPersonal.midStrr = mid;
//        studentPersonal.otherStr = @"1";
//        [self.navigationController pushViewController:studentPersonal animated:true];
//    }

    
}



- (CGPoint)randomPoint
{
    CGPoint randomPoint = CGPointZero;
    
    randomPoint.x = arc4random() % (int)(CGRectGetWidth(self.view.bounds));
    randomPoint.y = arc4random() % (int)(CGRectGetHeight(self.view.bounds));
    
    return randomPoint;
}

- (void)resetBtnClick:(UIButton *)button{
    [self.mapView setCenterCoordinate:self.mapView.userLocation.coordinate animated:YES];
}
#pragma mark - setter/getter
- (UIButton *)resetBtn{
    if (!_resetBtn) {
        _resetBtn = [[UIButton alloc]init];
        [_resetBtn setBackgroundImage:[UIImage imageNamed:@"map_location"] forState:UIControlStateNormal];
        _resetBtn.adjustsImageWhenDisabled = NO;
        [_resetBtn addTarget:self action:@selector(resetBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _resetBtn;
}

- (MAMapView *)mapView{
    
    if (_mapView == nil) {
        _mapView = [[MAMapView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.view.frame), CGRectGetHeight(self.view.frame))];
        _mapView.backgroundColor = [UIColor blackColor];
        _mapView.delegate = self;
        
        //为YES: 会调用代理方法。
        _mapView.customizeUserLocationAccuracyCircleRepresentation = YES;
        _mapView.showsBuildings = NO;//显示建筑物
        _mapView.skyModelEnable = NO;//天空模式
        _mapView.rotateEnabled = NO;//是否支持旋转
        _mapView.visibleMapRect = MAMapRectMake(220880104, 101476980, 272496, 466656);//可见位置
        _mapView.showsCompass = NO;
        _mapView.zoomLevel = 10;//设置缩放级别为0:10千米
        _mapView.minZoomLevel = 6;//
        _mapView.showsUserLocation = YES;    //YES 为打开定位，NO为关闭定位
        [_mapView setMapStatus:_mapView.getMapStatus animated:YES duration:2];
        
    }
    return _mapView;
}



-(void)scrollViewDidEndDecelerating:(MAUserHeadAnnotationView *)view {

    [self.currentAnnotationView closeAnimation];


    MAClusterPointAnnotation *clusterAnnotation = (MAClusterPointAnnotation *)view.annotation;
    [self.currentAnnotationView closeAnimation];
    [self.mapView selectAnnotation:self.currentAnnotationView.annotation animated:YES];

    [view setAnimation];
    [self.mapView selectAnnotation:clusterAnnotation animated:YES];
    self.currentAnnotationView = view;


}



- (void)showMapCardCollectionView{


    [UIView animateWithDuration:0.5 animations:^{
        if (self.mapType == TRZXMapType_Expert) {
            self.mapCardCollectionView.frame = CGRectMake(0, self.view.height-(MapExpertBottomHeight), self.view.width, MapExpertBottomHeight);
        }else if(self.mapType == TRZXMapType_Stockholder){
            self.mapCardCollectionView.frame = CGRectMake(0, self.view.height-(MapStockBottomHeight),  self.view.width, MapStockBottomHeight);
        }else{
            self.mapCardCollectionView.frame = CGRectMake(0, self.view.height-(MapInvistorBottomHeight),  self.view.width, MapInvistorBottomHeight);


        }
    }];





}
- (void)hiddenMapCardCollectionView{

    [UIView animateWithDuration:0.5 animations:^{
        if (self.mapType == TRZXMapType_Expert) {
            _mapCardCollectionView.frame = CGRectMake(0, self.view.height,  self.view.width, MapExpertBottomHeight);
        }else if(self.mapType == TRZXMapType_Stockholder){
            _mapCardCollectionView.frame = CGRectMake(0, self.view.height,  self.view.width, MapStockBottomHeight);
        }else{
            _mapCardCollectionView.frame = CGRectMake(0, self.view.height,  self.view.width, MapInvistorBottomHeight);

        }

    }];


}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
