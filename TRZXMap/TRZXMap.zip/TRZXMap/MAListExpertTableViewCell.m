//
//  MAListExpertTableViewCell.m
//  TRZX
//
//  Created by Rhino on 2016/12/23.
//  Copyright © 2016年 Tiancaila. All rights reserved.
//

#import "MAListExpertTableViewCell.h"
#import "TRZXKit.h"
#import "UIImageView+AFNetworking.h"

@implementation MAListExpertTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code

    self.zixunLabel.layer.borderColor = [UIColor trzx_NavTitleColor].CGColor;
    self.zixunLabel.layer.borderWidth = 0.5;
    self.zixunLabel.layer.cornerRadius = 2;
    self.zixunLabel.layer.masksToBounds = YES;
    
    self.headImage.layer.cornerRadius = 5;
    self.headImage.clipsToBounds = YES;

//    if ([[KPOUserDefaults mobile] isEqualToString:@"trzx"]) {
//        self.priceLabel.hidden = YES;
//        self.discountLabel.hidden =  YES;
//        self.ciLabel.hidden = YES;
//        self.yangLabel.hidden = YES;
//    }
}


//-(void)setModel:(MapUser *)model{
//
//
//    if (_model!=model) {
//        _model = model;
//        [self.headImage setImageWithURL:[NSURL URLWithString:model.photo]];
//        self.nameLabel.text = model.name;
//        self.distanceLabel.text = [NSString stringWithFormat:@"%@ 距离：%@",[model.isOnline isEqualToString:@"Online"]?@"在线":@"离线",model.distanceStr];
//        self.positionLabel.text = [NSString stringWithFormat:@"%@  %@",model.company,model.position];
//
//
//        self.priceLabel.text = [NSString stringWithFormat:@"%.1f",model.topic.vipOnce.floatValue] ;
//
//        if([model.topic.vipOnce integerValue]<[model.topic.muchOnce integerValue]){
//            _originalPriceLabel.text =[NSString stringWithFormat:@"￥%@/次",model.topic.muchOnce];
//        }else{
//            _originalPriceLabel.hidden = YES;
//            _discountLabel.hidden = YES;
//            _yjLabel.hidden = YES;
//            _priceLabel.textColor = [UIColor trzx_NavTitleColor];
//            _ciLabel.textColor = [UIColor trzx_NavTitleColor];
//            _yangLabel.textColor = [UIColor trzx_NavTitleColor];
//
//        }
//
//        //中划线
//
//        NSDictionary *attribtDic = @{NSStrikethroughStyleAttributeName: [NSNumber numberWithInteger:NSUnderlineStyleSingle]};
//
//        //下划线
//
//        //        NSDictionary *attribtDic = @{NSUnderlineStyleAttributeName: [NSNumber numberWithInteger:NSUnderlineStyleSingle]};
//
//        NSMutableAttributedString *attribtStr = [[NSMutableAttributedString alloc]initWithString:_originalPriceLabel.text attributes:attribtDic];
//        _originalPriceLabel.attributedText = attribtStr;
//
//        self.titleLabel.text = model.topic.topicTitle;
//        self.sexImage.image = [model.sex isEqualToString:@"男"]?[UIImage imageNamed:@"map_sex_man"]:[UIImage imageNamed:@"map_sex_woman"];
//
//    }
//    
//    
//}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
