//
//  TRMapStockCollectionViewCell.h
//  TRZX
//
//  Created by Rhino on 2016/12/20.
//  Copyright © 2016年 Tiancaila. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MapUser.h"
static NSString *kCellIdentifier_TRMapUserCollectionViewCell = @"TRMapUserCollectionViewCell";

///////股东
@interface TRMapUserCollectionViewCell : UICollectionViewCell
@property (nonatomic, assign)MapUser *model;

@end
