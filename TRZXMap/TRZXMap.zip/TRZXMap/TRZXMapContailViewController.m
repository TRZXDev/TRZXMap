//
//  TRZXMapContailViewController.m
//  TRZX
//
//  Created by Rhino on 2016/12/20.
//  Copyright © 2016年 Tiancaila. All rights reserved.
//

#import "TRZXMapContailViewController.h"
#import "TRZXMapViewController.h"
#import "TRZXMapListViewController.h"
#import "TRMapZoneViewController.h"
#import "MapDVSwitch.h"
#import "MapSearchTypeScrollView.h"//滚动标签
#import "KipoUpLocationManage.h"
#import "Masonry.h"
#import "TRZXKit.h"

@interface TRZXMapContailViewController ()<UIScrollViewDelegate>

//筛选
@property (nonatomic,strong)UIButton *fiterBtn;
//发布
@property (nonatomic,strong)UIButton *publishBtn;
//资源
@property (nonatomic,strong)UIButton *resourceBtn;

//滚动视图
@property (nonatomic,strong)UIScrollView *scrollViewControll;
//开关
@property (nonatomic,strong)MapDVSwitch *switcher;
@property (nonatomic)NSInteger switcherIndex;


//头部滚动标签
@property (nonatomic,strong)MapSearchTypeScrollView *expertView;
@property (nonatomic,strong)NSString *expertsPositionId;


@property (nonatomic,strong)TRZXMapViewController *oneVC;
@property (nonatomic,strong)TRZXMapListViewController *twoVC;


@property (nonatomic,strong)TRMapZoneViewController *zoneVc;

@property (nonatomic,strong)City *currentCity;
@property (nonatomic,strong)City *tempCity;



@end

@implementation TRZXMapContailViewController

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];

}

- (void)viewDidLoad {
    [super viewDidLoad];
   self.navigationItem.titleView = self.switcher;
    self.mapType == TRZXMapType_Stockholder;



    _oneVC = [[TRZXMapViewController alloc] init];
    _oneVC.mapType = self.mapType;
    _oneVC.view.frame = CGRectMake(0, 0, self.view.width, self.view.height);
    [self addChildViewController:_oneVC];
    [self.scrollViewControll addSubview:_oneVC.view];

    _oneVC.mapInitCompleteBlock = ^(MAMapView *mapView,City *city,City *tempCity){
        _currentCity = city;
        _tempCity =tempCity;
        [self setCurrentCityBtn:tempCity];
    };



    _twoVC = [[TRZXMapListViewController alloc] init];
    _twoVC.mapType = self.mapType;
    _twoVC.currentCity = _currentCity;
    _twoVC.view.frame = CGRectMake(self.view.width, 0,  self.view.width, self.scrollViewControll.height);
    [self addChildViewController:_twoVC];

    [self.scrollViewControll addSubview:_twoVC.view];




    _expertsPositionId = @"";

    self.switcherIndex = 0;

    //上传位置信息
    [self uploadMyLocation];
    [self createUI];
    [self addButton];
}


#pragma mark - UI
- (void)createUI
{



    //添加滚动视图 用于承载地图和列表页
    [self.view addSubview:self.scrollViewControll];
    
    if (self.mapType == TRZXMapType_Expert) {
         MapheaderViewbutton = 40;
        [self.view addSubview:self.expertView];


//        [[Kipo_NetAPIManager sharedManager] request_UserTitle_ApiWithBlock:^(id data, NSError *error) {
//            if (data) {
//
//                NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"全部", @"name",@"", @"mid",nil];
//                NSMutableArray *dicArray = [NSMutableArray arrayWithArray:data[@"list"]];
//                [dicArray insertObject:dic atIndex:0];
//                self.expertView.titleArr = dicArray;
//            }
//        }];


       
    }else{
        MapheaderViewbutton = 0;
    }
}

- (void)addButton{
    
    CGFloat width= 40;
    CGFloat height = 40;
    CGFloat topGap = 64 + 8;
    CGFloat gap = 10;
    
    if (self.mapType == TRZXMapType_Expert) { // 专家
        [self.view addSubview:self.publishBtn];
        [self.publishBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.view).offset(topGap + MapheaderViewbutton);
            make.right.equalTo(self.view).offset(-gap);
            make.height.equalTo(@(width));
            make.width.equalTo(@(height));
        }];

//        if (![KPOUserDefaults currentSessionUserTypeIsExpert]) {
//            self.publishBtn.hidden = YES;
//        }

        
       
    }else if(self.mapType == TRZXMapType_Stockholder){  // 股东
        [self.view addSubview:self.fiterBtn];
//        [self.view addSubview:self.resourceBtn];
//        [self.view addSubview:self.publishBtn];
//        zjself;


        [self.fiterBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.view).offset(topGap);
            make.right.equalTo(self.view).offset(-gap);
            make.height.equalTo(@(width));
            make.width.equalTo(@(height));
        }];


//        // 附近项目
//        [self.resourceBtn mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.top.equalTo(self.view).offset(topGap);
//            make.right.equalTo(self.view).offset(-gap);
//            make.height.equalTo(@(width));
//            make.width.equalTo(@(height));
//        }];
//        
//        [self.fiterBtn mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.top.equalTo(sfself.resourceBtn.mas_bottom).offset(gap);
//            make.right.equalTo(sfself.resourceBtn.mas_right);
//
//            make.height.equalTo(@(width));
//            make.width.equalTo(@(height));
//        }];
//        [self.publishBtn mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.top.equalTo(sfself.fiterBtn.mas_bottom).offset(gap);
//            make.right.equalTo(sfself.fiterBtn.mas_right);
//            make.height.equalTo(@(width));
//            make.width.equalTo(@(height));
//        }];
//
//        if (![KPOUserDefaults currentSessionUserTypeIsShare]) {
//            self.publishBtn.hidden = YES;
//        }



    }else{ // 投资人

        [self.view addSubview:self.fiterBtn];
//        [self.view addSubview:self.publishBtn];
        [self.fiterBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.view).offset(64+8);
            make.right.equalTo(self.view).offset(-gap);
            make.height.equalTo(@(width));
            make.width.equalTo(@(height));
        }];
//        [self.publishBtn mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.top.equalTo(sfself.fiterBtn.mas_bottom).offset(gap);
//            make.right.equalTo(sfself.fiterBtn.mas_right);
//            make.height.equalTo(@(width));
//            make.width.equalTo(@(height));
//        }];
    }
}



-(void)setCurrentCityBtn:(City *)city{


//    self.saveBtn.hidden = NO;
//    self.saveBtn.userInteractionEnabled = YES;
//
//    if (city.name.length>0) {
//        if ([city.name hasSuffix:@"市"]) {
//            [self.saveBtn setTitle: [city.name substringToIndex:[city.name length]-1] forState:UIControlStateNormal];
//        }else{
//            [self.saveBtn setTitle:city.name forState:UIControlStateNormal];
//        }
//    }

}




#pragma mark - 地区选择

- (void)saveAction{

        _zoneVc = [[TRMapZoneViewController alloc]init];
        _zoneVc.cityCallback = ^(City *city){

            _oneVC.tempCity = city;
            _twoVC.tempCity = city;
            [self setCurrentCityBtn:city];
        };
    [self.navigationController pushViewController:_zoneVc animated:YES];

}

- (void)toZoneVc{
    


}

#pragma mark - 项目筛选
- (void)fiterBtnClick:(UIButton *)button{



}



//-(FilterViewController *)filterViewController{
//    if (!_filterViewController) {
//        FilterAccessType accessType = self.mapType == TRZXMapType_Inverstor?FilterAccessTypeInvestor : FilterAccessTypeProject;
//        _filterViewController = [FilterViewController initWithAccessType:accessType Block:^(NSString *tradeStr, NSString *stageStr) {
//            NSArray *tradeId;
//            NSArray *stageId; //阶段id数组
//            if (tradeStr.length>0) {
//                tradeId = [tradeStr componentsSeparatedByString:@","]; //领域id数组
//            }
//            if (stageStr.length>0) {
//                stageId = [stageStr componentsSeparatedByString:@","]; //阶段id数组
//            }
//            
//            [_oneVC setTradeIds:tradeId stageIds:stageId];
//            [_twoVC setTradeIds:tradeId stageIds:stageId];
//
//
////            if (self.switcherIndex==0) {
////                [_oneVC setTradeIds:tradeId stageIds:stageId];
////            }else{
////                [_twoVC setTradeIds:tradeId stageIds:stageId];
////            }
//        }];
//    }
//    return _filterViewController;
//}


#pragma mark -发布需求
- (void)publishBtnClick:(UIButton *)button{


}

#pragma mark - 股东融资项目
- (void)resourceBtnClick:(UIButton *)button{


}

#pragma mark -上传我的位置信息
- (void)uploadMyLocation
{
    if (![self isOpenLocation]) {
        [self alertLocation];
        return;
    }
    KipoUpLocationManage *manage = [KipoUpLocationManage sharedManager];
    manage.locationDelegate = self;
    [manage startLocation];
    manage.block = ^(City *model){
        _oneVC.currentCity = model;
        _twoVC.currentCity = model;
        [self setCurrentCityBtn:model];

    };
}





- (BOOL)isOpenLocation
{
    if ([CLLocationManager authorizationStatus] == kCLAuthorizationStatusDenied){
        return NO;
    }
    return YES;
}
- (void)alertLocation
{
    UIAlertView *alert;
    if ([[[UIDevice currentDevice] systemVersion] floatValue] < 8.0) {
        alert = [[UIAlertView alloc] initWithTitle:@"定位服务未开启"
                                           message:@"请在iPhone的“设置”-“隐私”-“定位”中，找到投融在线更改"
                                          delegate:nil
                                 cancelButtonTitle:@"确定"
                                 otherButtonTitles:nil, nil];
    } else {
        alert = [[UIAlertView alloc] initWithTitle:@"定位服务未开启"
                                           message:@"请在系统设置中开启定位服务,发现更多周边专家,股东,投资人哦"
                                          delegate:self
                                 cancelButtonTitle:@"忽略"
                                 otherButtonTitles:@"前往", nil];
    }
    [alert show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 1) {
        [[UIApplication sharedApplication] openURL:[NSURL  URLWithString:UIApplicationOpenSettingsURLString]];
    }
}
#pragma mark- setter/getter

- (UIButton *)publishBtn{
    if (!_publishBtn) {
        _publishBtn = [[UIButton alloc]init];
        [_publishBtn setBackgroundImage:[UIImage imageNamed:@"map_publish"] forState:UIControlStateNormal];
        _publishBtn.adjustsImageWhenDisabled = NO;
        [_publishBtn addTarget:self action:@selector(publishBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _publishBtn;
}
- (UIButton *)fiterBtn{
    if (!_fiterBtn) {
        _fiterBtn = [[UIButton alloc]init];
        [_fiterBtn setBackgroundImage:[UIImage imageNamed:@"map_fifter"] forState:UIControlStateNormal];
        _fiterBtn.adjustsImageWhenDisabled = NO;
        [_fiterBtn addTarget:self action:@selector(fiterBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _fiterBtn;
}
- (UIButton *)resourceBtn{
    if (!_resourceBtn) {
        _resourceBtn = [[UIButton alloc]init];
        [_resourceBtn setBackgroundImage:[UIImage imageNamed:@"map_project"] forState:UIControlStateNormal];
        _resourceBtn.adjustsImageWhenDisabled = NO;
        [_resourceBtn addTarget:self action:@selector(resourceBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _resourceBtn;
}

//滚动视图 承载地图和列表两个view
- (UIScrollView *)scrollViewControll
{
    if (!_scrollViewControll) {
        _scrollViewControll = [[UIScrollView alloc]init];
        _scrollViewControll.frame = CGRectMake(0, 0, self.view.width, self.view.height);
        _scrollViewControll.showsHorizontalScrollIndicator = NO;
        _scrollViewControll.showsVerticalScrollIndicator = NO;
        _scrollViewControll.delegate = self;
        _scrollViewControll.scrollEnabled = NO;
        _scrollViewControll.contentSize = CGSizeMake(self.view.width *2, _scrollViewControll.frame.size.height);
    }
    return _scrollViewControll;
}

//开关 切换切面
- (MapDVSwitch *)switcher
{
    if (!_switcher) {
        NSArray *itemArr = @[@"地图",@"列表"];
        _switcher = [[MapDVSwitch alloc] initWithStringsArray:itemArr];
        _switcher.frame = CGRectMake((self.view.width-self.view.width*0.5)/2, 28, self.view.width *0.5, 30);
        
        _switcher.layer.cornerRadius = 16;
        _switcher.sliderOffset = 1.0;
        _switcher.font = [UIFont systemFontOfSize:14];
        _switcher.backgroundColor = [UIColor whiteColor];
        _switcher.sliderColor = [UIColor trzx_RedColor];;
        _switcher.labelTextColorInsideSlider = [UIColor whiteColor];
        _switcher.labelTextColorOutsideSlider = [UIColor trzx_RedColor];
        
        __weak TRZXMapContailViewController *weakSelf = self;
        [self.switcher setPressedHandler:^(NSUInteger index) {

            weakSelf.switcherIndex = index;
            if (index == 0)
            {
                [weakSelf.oneVC setExpertsPositionId:_expertsPositionId];

                [weakSelf.scrollViewControll setContentOffset:CGPointMake(0, 0) animated:YES];
            }else
            { //列表

                _twoVC.tempCity = _tempCity;
                _twoVC.currentCity = _currentCity;
                [weakSelf.twoVC setExpertsPositionId:_expertsPositionId];

                if (_twoVC.tempCity&&_twoVC.currentCity) {
                    [weakSelf.scrollViewControll setContentOffset:CGPointMake(self.view.width, 0) animated:YES];
                }


            }
        }];
        
    }
    return _switcher;
}

//头标签按钮-----可滚动
- (MapSearchTypeScrollView *)expertView
{
    __weak TRZXMapContailViewController *weakSelf = self;
    if (!_expertView) {
        _expertView = [[MapSearchTypeScrollView alloc]initWithFrame:CGRectMake(0, 64, self.view.width, MapheaderViewbutton)];
        _expertView.backgroundColor = [UIColor whiteColor];//;
        _expertView.buttonSearchTypeClick = ^(NSInteger index){

            NSDictionary *dic =weakSelf.expertView.titleArr[index];

            _expertsPositionId = dic[@"mid"];


            if (self.mapType == TRZXMapType_Expert) {
                if (_switcherIndex==0) {
                    [weakSelf.oneVC setExpertsPositionId:dic[@"mid"]];
                }else{
                    [weakSelf.twoVC setExpertsPositionId:dic[@"mid"]];
                }
            }

        };
    }
    return _expertView;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

//- (void)createUI
//{
//    self.view.backgroundColor = [UIColor whiteColor];
//    self.navigationItem.titleView = self.switcher;
//    //    self.navigationView.backgroundColor = RGBA(240, 239, 244, 1.0);
//    //    [self.navigationView addSubview:self.switcher];
//    self.navigationItem.leftBarButtonItem = [UIBarButtonItem kipo_LeftTarButtonItemDefaultTarget:self titelabe:@"返回" color:zideColor action:@selector(leftBarButtonItemPressed:)];
//    [self setRightButton:@"地区"];
//    //添加滚动视图 用于承载地图和列表页
//    [self.view addSubview:self.scrollViewControll];
//    
//    if (self.mapType == TRZXMapType_Expert) {
//        MapheaderViewbutton = 40;
//        [self.view addSubview:self.expertView];
//        self.expertView.titleArr = @[@"全部",@"律师",@"会计师",@"税务师",@"投融专家",@"评估师",@"券商"];
//        
//    }else{
//        MapheaderViewbutton = 0;
//    }
//}
//
//- (void)setRightButton:(NSString *)title{
//    UIButton *button = [[UIButton alloc]init];
//    [button setTitle:title forState:UIControlStateNormal];
//    [button setTitleColor:grayKColor forState:UIControlStateNormal];
//    [button addTarget:self action:@selector(rightBarButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
//    button.userInteractionEnabled = YES;
//    button.adjustsImageWhenDisabled = NO;
//    [button sizeToFit];
//    self.zoneBtn = button;
//    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:button];
//}
