//
//  TRZXMapListViewController.m
//  TRZX
//
//  Created by Rhino on 2016/12/20.
//  Copyright © 2016年 Tiancaila. All rights reserved.
//



//c
#import "TRZXMapListViewController.h"
//v
#import "MAListExpertTableViewCell.h"
#import "MAListStockTableViewCell.h"
#import "MAListInvistorTableViewCell.h"
#import "TRZXMapHeader.h"
#import "MapListModel.h"
#import "TRZXDIYRefresh.h"
#import "TRZXKit.h"
static NSString  *listIdentifierExpert = @"MAListExpertTableViewCell";
static NSString  *listIdentifierStock = @"MAListStockTableViewCell";
static NSString  *listIdentifierInvistor = @"MAListInvistorTableViewCell";


@interface TRZXMapListViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic,strong)NSMutableArray *dataSource;
@property (nonatomic,assign)CLLocationCoordinate2D userLocation;

@property (nonatomic,strong)NSArray *tradeIds;
@property (nonatomic,strong)NSArray *stageIds;
@property (nonatomic,strong)MapListModel *mapListModel;
@property (nonatomic,strong)NSString *expertsPositionId;


@end

@implementation TRZXMapListViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];

    [self addUI];
    [self addNotice];

    _mapListModel = [[MapListModel alloc]init];





    
}

//领域id数组  //阶段id数组
-(void)setTradeIds:(NSArray*)tradeIds stageIds:(NSArray *)stageIds{
    _tradeIds = tradeIds;
    _stageIds = stageIds;
    [self.tableView.mj_header beginRefreshing];

}

// 专家地图分类筛选
-(void)setExpertsPositionId:(NSString*)mid{

    _expertsPositionId = mid;
    [self.tableView.mj_header beginRefreshing];
}

-(void)setTempCity:(City *)tempCity{
    _tempCity = tempCity;
    [self.tableView.mj_header beginRefreshing];


}



- (void)refresh{
    _mapListModel.willLoadMore = NO;
    [_tableView.mj_footer resetNoMoreData];

    [self sendRequest];
}

- (void)refreshMore{
    if (!_mapListModel.canLoadMore) {
        [_tableView.mj_footer setState:MJRefreshStateNoMoreData];
        return;

    }
    _mapListModel.willLoadMore = YES;
    [self sendRequest];
}


-(void)sendRequest{



//    __weak typeof(self) weakSelf = self;
//    [[Kipo_NetAPIManager sharedManager] request_map_places_findListByInvWith:[_mapListModel toTipsParams:_currentCity tempCity:_tempCity mapType:_mapType tradeIds:_tradeIds stageIds:_stageIds expertsPositionId:_expertsPositionId] Block:^(id data, NSError *error) {
//        [weakSelf.view endLoading];
//
//        NSMutableArray *datas = data;
//
//        if (_mapListModel.willLoadMore) {
//            [_tableView.mj_footer endRefreshing];
//            [_mapListModel.data addObjectsFromArray:datas];
//
//        }else{
//            [_tableView.mj_header endRefreshing];
//            _mapListModel.data = [NSMutableArray arrayWithArray:datas];
//        }
//
//        if (_mapListModel.data.count>0) {
//            MapUser *modl = _mapListModel.data[_mapListModel.data.count-1];
//            _mapListModel.distance = modl.distance;
//            _mapListModel.objId = modl.objId;
//
//        }
//
//        [weakSelf.tableView reloadData];
//
//
//        self.bgdImage.hidden = YES;
//
//     if (_mapListModel.data.count==0) {
//         self.bgdImage.hidden = NO;
//     }else if (_mapListModel.data.count<15){
//     }
//
//      if (datas.count<15){
//         [_tableView.mj_footer setState:MJRefreshStateNoMoreData];
//     }
//
//
//        
//    }];



}









- (void)addUI{

    [self.view addSubview:self.tableView];
    self.tableView.frame = CGRectMake(0, 0, self.view.bounds.size.width,self.view.height-64);
    self.tableView.estimatedRowHeight = 200;  //  随便设个不那么离谱的值
    self.tableView.backgroundColor = [UIColor clearColor];
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    if (self.mapType == TRZXMapType_Expert) {
        [self.tableView registerNib:[UINib nibWithNibName:@"MAListExpertTableViewCell" bundle:nil] forCellReuseIdentifier:listIdentifierExpert];
        self.tableView.frame = CGRectMake(0, 0, self.view.bounds.size.width,self.view.height-64-40);

    }else if(self.mapType == TRZXMapType_Stockholder){
        [self.tableView registerNib:[UINib nibWithNibName:@"MAListStockTableViewCell" bundle:nil] forCellReuseIdentifier:listIdentifierStock];
    }else{
        [self.tableView registerNib:[UINib nibWithNibName:@"MAListInvistorTableViewCell" bundle:nil] forCellReuseIdentifier:listIdentifierInvistor];
    }
    self.tableView.mj_header = [TRZXGifHeader headerWithRefreshingBlock:^{
        [self.tableView.mj_footer resetNoMoreData];
        // 下拉刷新数据
        [self refresh];
    }];

    self.tableView.mj_footer =  [TRZXGifFooter footerWithRefreshingBlock:^{
        // 上拉加载数据
        [self refreshMore];
    }];
    self.tableView.mj_footer.automaticallyHidden = YES;
}

- (void)addNotice{
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(cityChange:) name:MAcityNotice object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(locationSuccess:) name:MALocationNotice object:nil];
}
#pragma mark - cell个数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _mapListModel.data.count;
}

#pragma mark - cell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    MapUser *model = self.mapListModel.data[indexPath.row];
    if (self.mapType == TRZXMapType_Expert) {
        MAListExpertTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:listIdentifierExpert forIndexPath:indexPath];
        cell.model = model;
        return cell;

    }else if(self.mapType == TRZXMapType_Stockholder){

        MAListStockTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:listIdentifierStock forIndexPath:indexPath];
        cell.model = model;
        return cell;
    }else{
        MAListInvistorTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:listIdentifierInvistor forIndexPath:indexPath];
        cell.model = model;
        return cell;
    }
}





#pragma mark - cell 点击事件
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    MapUser *model = self.mapListModel.data[indexPath.row];


//    if (![NSObject showCertificationTip:self]) {
//        PersonalInformationVC * studentPersonal=[[PersonalInformationVC alloc]init];
//        studentPersonal.midStrr = model.userId;
//        studentPersonal.otherStr = @"1";
//        [self.navigationController pushViewController:studentPersonal animated:true];
//
//    }


}
- (void)cityChange:(NSNotification *)noti{
    
    //NSDictionary *dict = noti.object;
    
}
- (void)locationSuccess:(NSNotification *)noti{
    

}



- (void)transToPersonalWithMid:(NSString *)mid
{
    
//    if (![NSObject showCertificationTip:self]) {
//        
//        PersonalInformationVC * studentPersonal=[[PersonalInformationVC alloc]init];
//        studentPersonal.midStrr = mid;
//        studentPersonal.otherStr = @"1";
//        [self.navigationController pushViewController:studentPersonal animated:true];
//    }
    
    
}



- (void)dealloc{
    
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}

//列表表格视图
- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
        _tableView.backgroundColor = [UIColor groupTableViewBackgroundColor];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.delegate = self;
        _tableView.dataSource = self;
    }
    return _tableView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{

    return 0.01;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{

    return 10;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
