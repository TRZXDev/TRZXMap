//
//  MapCardCollectionView.h
//  TRZX
//
//  Created by N年後 on 2016/12/31.
//  Copyright © 2016年 Tiancaila. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MapUser.h"
#import "MAClusterPointAnnotation.h"
#import "TRZXMapHeader.h"

@interface MapCardCollectionView : UIView
@property (nonatomic, copy) void(^scrollViewDidEndDeceleratingPagBlock)(NSInteger index);
@property (nonatomic, copy) void(^mapCardCollectionViewBlock)(MAClusterPointAnnotation *annotation);

- (instancetype)initWithFrame:(CGRect)frame  type:(TRZXMapType)type;

@property (nonatomic) TRZXMapType type;
@property (strong, nonatomic) UICollectionView *collectionView;
@property (nonatomic, strong) NSMutableArray *mapCards;


- (void)showMapCardCollectionViewWithIndex:(NSInteger)index;
- (void)hiddenMapCardCollectionView;




@end
