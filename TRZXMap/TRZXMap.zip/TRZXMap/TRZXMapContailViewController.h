//
//  TRZXMapContailViewController.h
//  TRZX
//
//  Created by Rhino on 2016/12/20.
//  Copyright © 2016年 Tiancaila. All rights reserved.
//

#import "TRZXMapHeader.h"

@interface TRZXMapContailViewController : UIViewController

@property (nonatomic,assign)TRZXMapType mapType;


@end
