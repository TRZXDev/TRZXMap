//
//  KipoSearchTypePopView.h
//  tourongzhuanjia
//
//  Created by 投融在线 on 16/4/22.
//  Copyright © 2016年 JWZhang. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol KipoSearchTypePopViewdelegate <NSObject>

@optional
- (void)viewHeight:(CGFloat)height;
- (void)itemPressedWithIndex:(NSInteger)index;

@end


@interface KipoSearchTypePopView : UIView

@property (nonatomic, weak)     id      <KipoSearchTypePopViewdelegate>delegate;

@property (nonatomic,strong)NSArray *titleArray;

@end
