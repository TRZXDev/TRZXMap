//
//  MapListModel.h
//  TRZX
//
//  Created by N年後 on 2017/1/7.
//  Copyright © 2017年 Tiancaila. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MapUser.h"
#import "City.h"
#import "TRZXMapHeader.h"
@interface MapListModel : NSObject
@property (assign, nonatomic) BOOL canLoadMore, willLoadMore, isLoading;
@property (readwrite, nonatomic, strong) NSMutableArray *data;
@property (assign, nonatomic) NSString* distance;
@property (assign, nonatomic) NSString* objId;



-(NSDictionary *)toTipsParams:(City*)city tempCity:(City*)tempCity mapType:(TRZXMapType)mapType tradeIds:(NSArray*)tradeIds stageIds:(NSArray*)stageIds expertsPositionId:(NSString*)expertsPositionId;

- (void)configWithObj:(MapListModel *)model;


@end
