//
//  KipoUpLocationManage.h
//  tourongzhuanjia
//
//  Created by 投融在线 on 16/4/15.
//  Copyright © 2016年 JWZhang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "City.h"
#import "TRZXMapHeader.h"
@protocol KipoLocationDelegate <NSObject>

- (void)locationStarWithLocation:(CLLocation *)location regeocode:(AMapLocationReGeocode *)regeocode error:(NSError *)error;

@end
typedef void(^KipoUpLocationManageBlock)(City *model);


@interface KipoUpLocationManage : NSObject

//格式化位置信息字符串
@property (nonatomic,copy)NSString *myLocationStr;

//位置信息
@property (nonatomic,assign)  CLLocationCoordinate2D   curLocation;
@property (nonatomic,assign)  City *cityModel;


@property (nonatomic,weak)id <KipoLocationDelegate>locationDelegate;
@property (nonatomic, copy) KipoUpLocationManageBlock block;
@property (nonatomic,strong)AMapLocationReGeocode *locationReGeocode;

+ (instancetype)sharedManager;

- (void)startLocation;



@end
