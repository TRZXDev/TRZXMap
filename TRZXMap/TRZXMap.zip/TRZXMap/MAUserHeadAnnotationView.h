//
//  MAUserHeadAnnotationView.h
//  TRZX
//
//  Created by Rhino on 2016/12/21.
//  Copyright © 2016年 Tiancaila. All rights reserved.
//

#import "TRZXMapHeader.h"
#import "MAClusterPointAnnotation.h"
@interface MAUserHeadAnnotationView : MAAnnotationView
@property (nonatomic,copy)void (^maUserHeadAnnotationViewBlock)(MAUserHeadAnnotationView *view);

@property (nonatomic,strong)MAClusterPointAnnotation *clusterAnnotation;

@property (nonatomic,strong)UIImageView *headImageView;
@property (nonatomic,strong)UILabel *titleLabel;
@property (nonatomic,strong)UIImageView *bgImageView;

- (void)setAnimation;
- (void)setAnimation0;
- (void)closeAnimation;
-(void)actionTap;
@end
