//
//  MapCardCollectionView.m
//  TRZX
//
//  Created by N年後 on 2016/12/31.
//  Copyright © 2016年 Tiancaila. All rights reserved.
//

#import "MapCardCollectionView.h"
#import "TRMapExpertCollectionViewCell.h"
#import "TRMapUserCollectionViewCell.h"
#import "MapUser.h"
#import "TRZXKit.h"
@interface MapCardCollectionView () <UICollectionViewDataSource,UICollectionViewDelegate>



@end

@implementation MapCardCollectionView



- (instancetype)initWithFrame:(CGRect)frame  type:(TRZXMapType)type
{
    self = [super initWithFrame:frame];
    if (self) {

        self.type = type;

        CGFloat itemW =frame.size.width;
        CGFloat itemH = 0;

        if (self.type == TRZXMapType_Expert) {
            itemH = MapExpertBottomHeight;
        }else if(self.type == TRZXMapType_Stockholder){
            itemH = MapStockBottomHeight;

        }else{
            itemH = MapInvistorBottomHeight;

        }
        // layout
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;

        layout.sectionInset = UIEdgeInsetsMake(0,0,0,0);
        layout.itemSize = CGSizeMake(itemW, itemH);
        layout.minimumLineSpacing = 0;
        layout.minimumInteritemSpacing = 0;


        self.collectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, self.width, itemH) collectionViewLayout:layout];
        self.collectionView.backgroundColor = [UIColor clearColor];
        self.collectionView.scrollsToTop = YES;
        self.collectionView.pagingEnabled = YES;
        self.collectionView.showsVerticalScrollIndicator = NO;
        self.collectionView.showsHorizontalScrollIndicator = NO;
        self.collectionView.dataSource = self;
        self.collectionView.delegate = self;
        // register cell

        [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([TRMapExpertCollectionViewCell class]) bundle:nil] forCellWithReuseIdentifier:kCellIdentifier_TRMapExpertCollectionViewCell];
        [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([TRMapUserCollectionViewCell class]) bundle:nil] forCellWithReuseIdentifier:kCellIdentifier_TRMapUserCollectionViewCell];


        [self addSubview:self.collectionView];


    }
    return self;
}







-(void)setMapCards:(NSMutableArray *)mapCards{
        _mapCards = mapCards;
        [_collectionView reloadData];   
}

#pragma mark - UICollectionViewDataSource

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{

    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{

    return _mapCards.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
     MAClusterPointAnnotation *annotation = _mapCards[indexPath.row];


    if (_type == TRZXMapType_Expert) {  // 专家

        TRMapExpertCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:kCellIdentifier_TRMapExpertCollectionViewCell forIndexPath:indexPath];
        cell.model = annotation.model;
        return cell;


    }else {

        TRMapUserCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:kCellIdentifier_TRMapUserCollectionViewCell forIndexPath:indexPath];
        cell.model = annotation.model;
        return cell;



        //        if ([annotation.model.type isEqualToString:@"Project"]) {
        //
        //            TRMapProjectCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:kCellIdentifier_TRMapProjectCollectionViewCell forIndexPath:indexPath];
        //            cell.model = annotation.model;
        //            return cell;
        //
        //        }else{
        //
        //            TRMapStockCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:kCellIdentifier_TRMapStockCollectionViewCell forIndexPath:indexPath];
        //            cell.model = annotation.model;
        //            return cell;
        //            
        //        }


    }


}

#pragma mark - UICollectionViewDelegate

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{

    MAClusterPointAnnotation *annotation = _mapCards[indexPath.row];
    if (self.mapCardCollectionViewBlock) {
        self.mapCardCollectionViewBlock(annotation);
    }

}


- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    // 动画停止, 重新定位到第 50 组模型
    int inc = ((int)(scrollView.contentOffset.x / scrollView.frame.size.width)) % _mapCards.count;
    if (self.scrollViewDidEndDeceleratingPagBlock) {
        self.scrollViewDidEndDeceleratingPagBlock(inc);
    }
}

- (void)showMapCardCollectionViewWithIndex:(NSInteger)index{

    [self.collectionView scrollToItemAtIndexPath:[NSIndexPath indexPathForItem:index inSection:0]atScrollPosition:UICollectionViewScrollPositionNone animated:NO];
    [UIView animateWithDuration:0.2f animations:^{
        self.frame = CGRectMake(0, self.height, [[UIScreen mainScreen] bounds].size.width, self.height);
    }];

}
- (void)hiddenMapCardCollectionView{

    [UIView animateWithDuration:0.2f animations:^{
        self.frame = CGRectMake(0, -[[UIScreen mainScreen] bounds].size.height, [[UIScreen mainScreen] bounds].size.width, self.height);

    }];
}


@end
