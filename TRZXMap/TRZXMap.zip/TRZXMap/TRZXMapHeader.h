
//
//  TRZXMapHeader.h
//  TRZX
//
//  Created by Rhino on 2016/12/20.
//  Copyright © 2016年 Tiancaila. All rights reserved.
//


#import <AMapFoundationKit/AMapFoundationKit.h>//引入地图功能所有的头文件
#import <AMapSearchKit/AMapSearchKit.h> // 引入搜索头文件
#import <AMapLocationKit/AMapLocationKit.h> // 引入定位头文件
#import <MAMapKit/MAMapKit.h> // 引入定位头文件


// 高德地图
#define kAMapAppKey @"f1060ef1f62bef18731182fa5983ddf8"
/**地图类型 ?*/
typedef NS_ENUM(NSInteger, TRZXMapType) {
    TRZXMapType_Expert,//专家
    TRZXMapType_Stockholder,//股东
    TRZXMapType_Inverstor,//投资人
};

//头标签 高度
static CGFloat MapheaderViewbutton = 40;
static CGFloat MapStockBottomHeight = 97;
static CGFloat MapExpertBottomHeight = 155;
static CGFloat MapInvistorBottomHeight = 172;
static CGFloat MapBottomMaiginHeight = 25;

static NSString * const MAcityNotice = @"MAcityNotice";
static NSString * const MALocationNotice = @"MALocationNotice";



