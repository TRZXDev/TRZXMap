//
//  TRMapExpertCollectionViewCell.h
//  TRZX
//
//  Created by Rhino on 2016/12/20.
//  Copyright © 2016年 Tiancaila. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HCSStarRatingView.h"
#import "MapUser.h"
static NSString *kCellIdentifier_TRMapExpertCollectionViewCell = @"TRMapExpertCollectionViewCell";

///////专家
@interface TRMapExpertCollectionViewCell : UICollectionViewCell
@property (nonatomic, assign)MapUser *model;

@property (weak, nonatomic) IBOutlet HCSStarRatingView *starView;

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIImageView *headImage;
@property (weak, nonatomic) IBOutlet UILabel *namelabel;
@property (weak, nonatomic) IBOutlet UIImageView *sexImage;
@property (weak, nonatomic) IBOutlet UILabel *positionLabel;
@property (weak, nonatomic) IBOutlet UILabel *distanceLabel;


@property (weak, nonatomic) IBOutlet UILabel *yangLabel;
@property (weak, nonatomic) IBOutlet UILabel *priceLabel;
@property (weak, nonatomic) IBOutlet UILabel *ciLabel;
@property (weak, nonatomic) IBOutlet UILabel *discountLabel;
@property (weak, nonatomic) IBOutlet UILabel *yjLabel; // 原价
@property (weak, nonatomic) IBOutlet UILabel *originalPriceLabel;


@end
