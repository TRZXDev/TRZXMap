//
//  KipoUpLocationManage.m
//  tourongzhuanjia
//
//  Created by 投融在线 on 16/4/15.
//  Copyright © 2016年 JWZhang. All rights reserved.
//

#define LocationTimeout 15  //   定位超时时间，可修改，最小2s
#define ReGeocodeTimeout 15 //   逆地理请求超时时间，可修改，最小2s

#import "KipoUpLocationManage.h"
@interface KipoUpLocationManage ()<AMapLocationManagerDelegate>{
    
}

@property (nonatomic, strong) AMapLocationManager *location;

@property (nonatomic, copy) AMapLocatingCompletionBlock completionBlock;


@property (nonatomic, copy) NSString  *country;
@property (nonatomic, copy) NSString *province; //!< 省/直辖市
@property (nonatomic, copy) NSString *city;     //!< 市
@property (nonatomic, copy) NSString *district; //!< 区
@property (nonatomic, copy) NSString *township;

@end
@implementation KipoUpLocationManage


///**第1步: 存储唯一实例*/
static  KipoUpLocationManage *_instan;
//
///**第2步: 分配内存孔家时都会调用这个方法. 保证分配内存alloc时都相同*/
+(id)allocWithZone:(struct _NSZone *)zone{
    //调用dispatch_once保证在多线程中也只被实例化一次
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instan = [super allocWithZone:zone];
        
    });
    return _instan;
}
//
///**第3步: 保证init初始化时都相同*/
+ (instancetype)sharedManager{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instan = [[KipoUpLocationManage alloc] init];
        
    });
    return _instan;
}
//
///**第4步: 保证copy时都相同*/
-(id)copyWithZone:(NSZone *)zone{
    return _instan;
}


- (void)startLocation
{
    [self initCompleteBlock];
    
    [self configLocationManager];
}

#pragma mark - 定位相关 自带逆地理编码
- (void)configLocationManager
{
    self.location = [[AMapLocationManager alloc] init];
    
    [self.location setDelegate:self];
    
    [self.location setDesiredAccuracy:kCLLocationAccuracyHundredMeters];
    
    [self.location setPausesLocationUpdatesAutomatically:NO];
    //要在iOS 9及以上版本使用后台定位功能, 需要保证"Background Modes"中的"Location updates"处于选中状态
    [self.location setAllowsBackgroundLocationUpdates:NO];
    //   定位超时时间，最低2s，此处设置为2s
    self.location.locationTimeout =2;
    //   逆地理请求超时时间，最低2s，此处设置为2s
    self.location.reGeocodeTimeout = 2;
    [self reGeocodeAction];
}

- (void)reGeocodeAction
{
    [self.location requestLocationWithReGeocode:YES completionBlock:self.completionBlock];
}

- (void)initCompleteBlock
{
    __weak KipoUpLocationManage *wSelf = self;
    self.completionBlock = ^(CLLocation *location, AMapLocationReGeocode *regeocode, NSError *error)
    {
        
        if ([wSelf.locationDelegate respondsToSelector:@selector(locationStarWithLocation:regeocode:error:)]) {
            [wSelf.locationDelegate locationStarWithLocation:location regeocode:regeocode error:error];
        }

        if (error)
        {
            if (error.code == AMapLocationErrorLocateFailed)
            {  //定位失败
                return;
            }
        }

        if (location &&regeocode) {
            NSDictionary *dict = @{
                                   @"location":location,
                                   @"regeocode":regeocode
                                   };
            [[NSNotificationCenter defaultCenter]postNotificationName:MALocationNotice object:dict];
        }

        
        if (location)
        {
            if (regeocode)
            {
                //位置坐标
                _curLocation = location.coordinate;
                //格式化字符串
                NSString *result = [NSString stringWithFormat:@"%@", regeocode.formattedAddress];
                wSelf.myLocationStr = result;

                wSelf.country = @"中国";
                wSelf.province = regeocode.province==nil?regeocode.province:@"";
                wSelf.city =  regeocode.city==nil?regeocode.city:@"";
                wSelf.district = regeocode.district==nil?regeocode.district:@"";
                    //上传信息
                NSString *lat = [NSString stringWithFormat:@"%f",wSelf.curLocation.latitude];
                NSString *lon = [NSString stringWithFormat:@"%f",wSelf.curLocation.longitude];

                if (regeocode.city.length <1) {
                    regeocode.city = @"";
                }
//                [[Kipo_NetAPIManager sharedManager] request_places_savePlacesWith:regeocode lon:lon lat:lat Block:^(id data, NSError *error) {
//                    City *cityModel = [[City alloc]init];
//                    cityModel.citycode = regeocode.adcode;
//                    cityModel.latitude = lat;
//                    cityModel.longitude = lon;
//                    cityModel.name = regeocode.city;
//                    if (wSelf.block) {
//                        wSelf.block(cityModel);
//                    }
//                }];


            }
        }
    };
}

- (void)uploadMyLocationWithReg:(AMapLocationReGeocode *)regeocode
{






}


@end
