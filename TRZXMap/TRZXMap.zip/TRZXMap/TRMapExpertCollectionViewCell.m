//
//  TRMapExpertCollectionViewCell.m
//  TRZX
//
//  Created by Rhino on 2016/12/20.
//  Copyright © 2016年 Tiancaila. All rights reserved.
//

#import "TRMapExpertCollectionViewCell.h"
#import "TRZXKit.h"
#import "UIImageView+AFNetworking.h"

@interface TRMapExpertCollectionViewCell()

@end

@implementation TRMapExpertCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code

    self.starView.userInteractionEnabled = NO;

    self.headImage.layer.cornerRadius = self.headImage.width/2;
    self.headImage.clipsToBounds = YES;


//    if ([[KPOUserDefaults mobile] isEqualToString:@"trzx"]) {
//        self.priceLabel.hidden = YES;
//        self.discountLabel.hidden =  YES;
//        self.ciLabel.hidden = YES;
//        self.yangLabel.hidden = YES;
//    }

}
-(void)setModel:(MapUser *)model{


//    if (_model!=model) {
//        _model = model;
//        [self.headImage setImageWithURL:[NSURL URLWithString:model.photo]];
//        self.namelabel.text = model.name;
//
//        self.distanceLabel.text = [NSString stringWithFormat:@"%@ 距离：%@",[model.isOnline isEqualToString:@"Online"]?@"在线":@"离线",model.distanceStr];
//
//        self.positionLabel.text = [NSString stringWithFormat:@"%@  %@",model.company,model.position];
//
//
//
//        self.priceLabel.text = [NSString stringWithFormat:@"%.1f",model.topic.vipOnce.floatValue] ;
//
//        if([model.topic.vipOnce integerValue]<[model.topic.muchOnce integerValue]){
//            _originalPriceLabel.text =[NSString stringWithFormat:@"￥%@/次",model.topic.muchOnce];
//        }else{
//            _originalPriceLabel.hidden = YES;
//            _discountLabel.hidden = YES;
//            _yjLabel.hidden = YES;
//            _priceLabel.textColor = zideColor;
//            _ciLabel.textColor = zideColor;
//            _yangLabel.textColor = zideColor;
//
//        }
//
//        //中划线
//
//        NSDictionary *attribtDic = @{NSStrikethroughStyleAttributeName: [NSNumber numberWithInteger:NSUnderlineStyleSingle]};
//
//        //下划线
//
//        //        NSDictionary *attribtDic = @{NSUnderlineStyleAttributeName: [NSNumber numberWithInteger:NSUnderlineStyleSingle]};
//
//        NSMutableAttributedString *attribtStr = [[NSMutableAttributedString alloc]initWithString:_originalPriceLabel.text attributes:attribtDic];
//        _originalPriceLabel.attributedText = attribtStr;
//
//
//
//
//        self.starView.value =  [model.topic.score integerValue];
//        self.titleLabel.text = model.topic.topicTitle;
//
//        self.sexImage.image = [model.sex isEqualToString:@"男"]?[UIImage imageNamed:@"map_sex_man"]:[UIImage imageNamed:@"map_sex_woman"];
//    }
    
    
}
@end
