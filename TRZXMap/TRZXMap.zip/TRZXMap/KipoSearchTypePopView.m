//
//  KipoSearchTypePopView.m
//  tourongzhuanjia
//
//  Created by 投融在线 on 16/4/22.
//  Copyright © 2016年 JWZhang. All rights reserved.
//
#define HeaderIdentifier @"header"
#import "KipoSearchTypePopView.h"
#import "TRZXKit.h"
@interface KipoSearchTypePopView ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>

@property (nonatomic,strong)UICollectionView *collectionView;

@end

@implementation KipoSearchTypePopView

- (UICollectionView *)collectionView
{
    if (!_collectionView) {
        
        UICollectionViewFlowLayout *flowLay = [[UICollectionViewFlowLayout alloc]init];
        _collectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, self.width, 150) collectionViewLayout:flowLay];
        _collectionView.backgroundColor = [UIColor blackColor];
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
    }
    return _collectionView;
}

- (void)setTitleArray:(NSArray *)titleArray
{
    _titleArray = titleArray;
    [self.collectionView reloadData];
}
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.userInteractionEnabled = YES;
        [self addUI];
        
    }
    return self;
}

- (void)addUI
{
    [self addSubview:self.collectionView];
    self.backgroundColor = [UIColor colorWithWhite:1 alpha:0.5];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(disappear)];
    [self addGestureRecognizer:tap];
    [self setUpViews];
}

- (void)setUpViews
{
    //注册页眉
    [self.collectionView registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:HeaderIdentifier];
    [self.collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"cell"];
    
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
     UICollectionViewCell *cell = [collectionView  dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    
    for (UIView *view in cell.contentView.subviews) {
        [view removeFromSuperview];
    }
    UILabel *lable = [[UILabel alloc]initWithFrame:cell.bounds];
    lable.font = [UIFont systemFontOfSize:13];
    lable.text = self.titleArray[indexPath.item];
    lable.textAlignment = NSTextAlignmentCenter;
    lable.textColor = [UIColor colorWithRed:90/255.0 green:90/255.0 blue:90/255.0 alpha:1];

    [cell.contentView addSubview:lable];
    
    return cell;
   
}
//分组头视图
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    if ([kind isEqualToString:UICollectionElementKindSectionHeader]) {
        UICollectionReusableView *headerView = nil;
        if (indexPath.section == 0) {
            headerView = [collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier:HeaderIdentifier forIndexPath:indexPath];
            
            [headerView addSubview:[self headerOfSectionFirst]];
            return headerView;
        }
    }
        return nil;
}
//头视图1
- (UIView *)headerOfSectionFirst
{
    UILabel *lable = [[UILabel alloc]init];
    lable.frame = CGRectMake(10, 0, self.width, 30);
    lable.text = @"切换分类";
    lable.font = [UIFont systemFontOfSize:14];
    lable.textColor = [UIColor colorWithRed:90/255.0 green:90/255.0 blue:90/255.0 alpha:1];;
    return lable;
}
//头视图尺寸
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section
{

  return CGSizeMake(self.width,30);

}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
 
    return self.titleArray.count;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    NSString *str = self.titleArray[indexPath.row];
    //计算字号 +2
    CGSize detailSize = [str sizeWithAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15]}];
    
    return detailSize;
}


- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    return 10;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
   
    [_delegate itemPressedWithIndex:indexPath.item];
    [self disappear];
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
        return UIEdgeInsetsMake(10, 10, 10, 10);
}

- (void)show
{
    [UIView animateWithDuration:0.2 animations:^{
        self.frame = CGRectMake(0, 0, self.width, self.height - 64-60);
//        self.collectionView.hidden = NO;
    }];
}
- (void)disappear
{
    [UIView animateWithDuration:0.2 animations:^{
        self.frame = CGRectMake(0, 0, self.width, 1);
//        self.collectionView.hidden = YES;
    }];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self disappear];
}
- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self disappear];
}
@end
