//
//  MapSearchTypeScrollView.m
//  tourongzhuanjia
//
//  Created by 投融在线 on 16/4/13.
//  Copyright © 2016年 JWZhang. All rights reserved.
//





#import "MapSearchTypeScrollView.h"
#import "KipoSearchTypePopView.h"
#import "TRZXKit.h"
@interface MapSearchTypeScrollView ()

{

    CGFloat btn_fondOfSize;
    CGFloat btn_Margin;
    CGFloat indicatorViewHeight;

}
@property (nonatomic,strong)UIScrollView *scrollView;
@property (nonatomic,strong)NSMutableArray *dataSource;
@property (nonatomic,assign)BOOL isGoleft;
@property (nonatomic,strong)UIView *indicatorView;
@property (nonatomic,strong)UIButton *selectedBtn;
@end

@implementation MapSearchTypeScrollView


- (UIScrollView *)scrollView
{
    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc]init];
        _scrollView.frame = CGRectMake(0, 0, self.width, 60);
        _scrollView.showsHorizontalScrollIndicator = NO;
        _scrollView.showsVerticalScrollIndicator = NO;
    }
    return _scrollView;
}
- (NSMutableArray *)dataSource
{
    if (_dataSource == nil) {
        _dataSource = [[NSMutableArray alloc]init];
    }
    return _dataSource;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {

        btn_fondOfSize = 15;
        btn_Margin = 15;
        /** 指示器的高度 */
        indicatorViewHeight = 3;


        [self addUI];
    }
    return self;
}

- (void)addUI
{
    self.userInteractionEnabled = YES;
    [self addSubview:self.scrollView];
    UIView *lineView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.width, 1)];
    lineView.backgroundColor = [UIColor colorWithRed:218.0/255.0 green:218.0/255.0 blue:218.0/255.0 alpha:1];
    [self addSubview:lineView];
}

- (void)setTitleArr:(NSArray *)titleArr
{
    _titleArr = titleArr;
    [self addButttonWithTitleArr:titleArr];
}

- (void)addButttonWithTitleArr:(NSArray *)titleArr
{
    
    CGFloat button_X = 0;
    CGFloat button_Y = 0;
    CGFloat button_H = self.frame.size.height;
    
    for (NSUInteger i = 0; i < titleArr.count; i++) {
        /** 创建滚动时的标题Label */
        UIButton *title_btn = [UIButton buttonWithType:(UIButtonTypeCustom)];
        
        title_btn.tag = i;
        title_btn.titleLabel.font = [UIFont systemFontOfSize:btn_fondOfSize];
        title_btn.tag = i;

        NSDictionary *dic = titleArr[i];
        
        // 计算内容的Size
        CGSize buttonSize = [self sizeWithText:dic[@"name"] font:[UIFont systemFontOfSize:btn_fondOfSize] maxSize:CGSizeMake(MAXFLOAT, button_H)];
        
        // 计算内容的宽度
        CGFloat button_W = 2 * btn_Margin + buttonSize.width;
        title_btn.frame = CGRectMake(button_X, button_Y, button_W, button_H);
        
        [title_btn setTitle:dic[@"name"] forState:(UIControlStateNormal)];
        [title_btn setTitleColor:[UIColor trzx_NavTitleColor] forState:(UIControlStateNormal)];
//        [title_btn setTitleColor:heizideColor forState:(UIControlStateSelected)];

        // 计算每个label的X值
        button_X = button_X + button_W;
        
        // 点击事件
        [title_btn addTarget:self action:@selector(listTypeClick:) forControlEvents:(UIControlEventTouchUpInside)];
        
        // 默认选中第0个button
        if (i == 0) {
            [title_btn setTitleColor:[UIColor lightGrayColor] forState:(UIControlStateNormal)];
            self.selectedBtn = title_btn;
        }
        
        // 存入所有的title_btn
        [self.dataSource addObject:title_btn];
        [self.scrollView addSubview:title_btn];
    }
    
    // 计算scrollView的宽度
    CGFloat scrollViewWidth = CGRectGetMaxX(self.scrollView.subviews.lastObject.frame);
    self.scrollView.contentSize = CGSizeMake(scrollViewWidth, self.frame.size.height);
    
    // 取出第一个子控件
    UIButton *firstButton = self.scrollView.subviews.firstObject;
    
    // 添加指示器
    self.indicatorView = [[UIView alloc] init];
    _indicatorView.backgroundColor = [UIColor trzx_RedColor];
    _indicatorView.frame = CGRectMake(0, 0, 30, indicatorViewHeight);
    [self.scrollView addSubview:_indicatorView];
    
    // 指示器默认在第一个选中位置
    // 计算TitleLabel内容的Size
    CGSize buttonSize = [self sizeWithText:firstButton.titleLabel.text font:[UIFont systemFontOfSize:btn_fondOfSize] maxSize:CGSizeMake(MAXFLOAT, self.frame.size.height)];
    _indicatorView.width = buttonSize.width + btn_Margin;
    _indicatorView.centerX = firstButton.centerX;
    _indicatorView.top = self.height - indicatorViewHeight - 1;
 
}

- (void)listTypeClick:(UIButton *)button
{
    NSInteger index = button.tag;


     //1.
    [self titleBtnSelectededCenter:button];
    
    //2.
    if (self.buttonSearchTypeClick) {
        self.buttonSearchTypeClick(index);
    }
    // 3、改变指示器位置
    [self titleBtnSelected:button];
    

}

/** 滚动标题选中居中 */
- (void)titleBtnSelectededCenter:(UIButton *)centerBtn {

    if (self.selectedBtn) {
        [ self.selectedBtn setTitleColor:[UIColor trzx_NavTitleColor] forState:(UIControlStateNormal)];
        self.selectedBtn = centerBtn;
    }

    [centerBtn setTitleColor:[UIColor blackColor] forState:(UIControlStateNormal)];


    // 计算偏移量
    CGFloat offsetX = centerBtn.center.x - self.width * 0.5;
    
    if (offsetX < 0) offsetX = 0;
    
    // 获取最大滚动范围
    CGFloat maxOffsetX = self.scrollView.contentSize.width - self.width;
    
    if (offsetX > maxOffsetX) offsetX = maxOffsetX;
    
    // 滚动标题滚动条
    [self.scrollView setContentOffset:CGPointMake(offsetX, 0) animated:YES];
}


/** 标题选中颜色改变以及指示器位置变化 */
- (void)titleBtnSelected:(UIButton *)button {
    

    [UIView animateWithDuration:0.2 animations:^{
        // 计算内容的Size
        CGSize buttonSize = [self sizeWithText:button.titleLabel.text font:[UIFont systemFontOfSize:btn_fondOfSize] maxSize:CGSizeMake(MAXFLOAT, self.frame.size.height - indicatorViewHeight)];
        self.indicatorView.width = buttonSize.width + btn_Margin;
        self.indicatorView.centerX = button.centerX;
    }];
    
}

/**
 *  计算文字尺寸
 *
 *  @param text    需要计算尺寸的文字
 *  @param font    文字的字体
 *  @param maxSize 文字的最大尺寸
 */
- (CGSize)sizeWithText:(NSString *)text font:(UIFont *)font maxSize:(CGSize)maxSize {
    NSDictionary *attrs = @{NSFontAttributeName : font};
    return [text boundingRectWithSize:maxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:attrs context:nil].size;
}


@end
