//
//  MapSearchTypeScrollView.h
//  tourongzhuanjia
//
//  Created by 投融在线 on 16/4/13.
//  Copyright © 2016年 JWZhang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MapSearchTypeScrollView : UIView

@property (nonatomic,strong)NSArray *titleArr;

@property (nonatomic,copy)void (^buttonSearchTypeClick)(NSInteger index);

@end
