//
//  TRZXMapViewController.h
//  TRZX
//
//  Created by Rhino on 2016/12/20.
//  Copyright © 2016年 Tiancaila. All rights reserved.
//

#import "TRZXMapHeader.h"
#import "City.h"
@interface TRZXMapViewController : UIViewController

@property (nonatomic, copy) void(^mapInitCompleteBlock)(MAMapView *mapView,City *city,City *tempCity);


@property (nonatomic,assign)TRZXMapType mapType;
@property (nonatomic,strong)City *currentCity;
@property (nonatomic,strong)City *tempCity;

//领域id数组  //阶段id数组
-(void)setTradeIds:(NSArray*)tradeIds stageIds:(NSArray *)stageIds;
// 专家地图分类筛选
-(void)setExpertsPositionId:(NSString*)mid;

@end
