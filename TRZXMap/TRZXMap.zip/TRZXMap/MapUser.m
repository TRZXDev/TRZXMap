//
//  MapUser.m
//  TRZX
//
//  Created by N年後 on 2017/1/4.
//  Copyright © 2017年 Tiancaila. All rights reserved.
//

#import "MapUser.h"

@implementation MapUser
+(NSDictionary *)replacedKeyFromPropertyName{
    return@{@"kdistance": @"distance",@"kcount":@"count"};
}



@end
