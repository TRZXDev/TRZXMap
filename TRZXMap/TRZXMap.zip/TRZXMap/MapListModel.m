//
//  MapListModel.m
//  TRZX
//
//  Created by N年後 on 2017/1/7.
//  Copyright © 2017年 Tiancaila. All rights reserved.
//

#import "MapListModel.h"

@implementation MapListModel
+(NSDictionary *)objectClassInArray{
    return @{@"data":[MapUser class]};
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        _canLoadMore = YES;
        _isLoading = _willLoadMore = NO;
        _distance = @"0";
    }
    return self;
}



-(NSDictionary *)toTipsParams:(City*)city tempCity:(City*)tempCity mapType:(TRZXMapType)mapType tradeIds:(NSArray*)tradeIds stageIds:(NSArray*)stageIds expertsPositionId:(NSString*)expertsPositionId {



    NSDictionary * userCoordinate = @{@"latitude":city.latitude==nil?@"":city.latitude,@"longitude":city.longitude==nil?@"":city.longitude};  //当前用户所在位置
    NSDictionary * coordinate = @{@"latitude":city.latitude==nil?@"":city.latitude,@"longitude":city.longitude==nil?@"":city.longitude};// 当前位置之外的位置
    NSMutableDictionary *params = [[NSMutableDictionary alloc]initWithObjectsAndKeys:userCoordinate, @"userCoordinate", coordinate, @"coordinate", nil];




    if (tradeIds.count>0) {
        [params setObject:tradeIds forKey:@"tradeId"];
    }
    if (stageIds.count>0) {
        [params setObject:stageIds forKey:@"stageId"];
    }


    if (mapType == TRZXMapType_Expert) {
        [params setObject:@"/api/map/places/findListByExpert" forKey:@"path"];

        if (expertsPositionId.length>0) {
            [params setObject:expertsPositionId forKey:@"userTitleId"];
        }

    }else if(mapType == TRZXMapType_Stockholder){
        [params setObject:@"/api/map/places/findListByShare" forKey:@"path"];
    }else{
        [params setObject:@"/api/map/places/findListByInv" forKey:@"path"];
    }


    [params setObject:_willLoadMore?_distance:@"0" forKey:@"minDistance"];
    [params setObject:_willLoadMore?_objId:@"" forKey:@"objId"];

    if (tempCity.citycode.length>0) {
        [params setObject:tempCity.citycode forKey:@"citycode"];
    }


    return params;
}


- (void)configWithObj:(MapListModel *)model{

    if (_willLoadMore) {
        [self.data addObjectsFromArray:model.data];
    }else{
        self.data = [NSMutableArray arrayWithArray:model.data];
    }

    if (self.data.count>0) {
        MapUser *modl = self.data[self.data.count-1];
        _distance = modl.distance;
    }



}

@end
