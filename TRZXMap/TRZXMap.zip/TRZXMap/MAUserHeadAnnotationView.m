//
//  MAUserHeadAnnotationView.m
//  TRZX
//
//  Created by Rhino on 2016/12/21.
//  Copyright © 2016年 Tiancaila. All rights reserved.
//

#import "MAUserHeadAnnotationView.h"
#import "TRZXKit.h"
static const CGFloat userScale = 1.2;

@interface MAUserHeadAnnotationView ()


@property (nonatomic,strong)CALayer *layers;

@end

@implementation MAUserHeadAnnotationView

- (id)initWithAnnotation:(id<MAAnnotation>)annotation reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithAnnotation:annotation reuseIdentifier:reuseIdentifier];
    
    if (self)
    {
        self.bounds = CGRectMake(0.f, 0.f, 47*1.3, 50*1.3);
        self.backgroundColor = [UIColor clearColor];

        _bgImageView = [[UIImageView alloc]initWithFrame:self.bounds];
        _bgImageView.image = [UIImage imageNamed:@"未选中"];
        [self addSubview:self.bgImageView];


        _titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(3, 3, self.width-6, self.width-6)];
        _titleLabel.textColor = [UIColor colorWithRed:209.0/255.0 green:187.0/255.0 blue:114.0/255.0 alpha:1];
        _titleLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview:self.titleLabel];



        _headImageView = [[UIImageView alloc]initWithFrame:CGRectMake(3, 3, self.width-6, self.width-6)];
        [self addSubview:self.headImageView];


        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(actionTap)];
        [self addGestureRecognizer:tap];

    }
    
    return self;
}



-(void)layoutSubviews{
    [super layoutSubviews];
    self.headImageView.layer.cornerRadius = _headImageView.width/2;
    self.headImageView.clipsToBounds = YES;

}






-(void)actionTap{
    if (self.maUserHeadAnnotationViewBlock) {
        self.maUserHeadAnnotationViewBlock(self);
    }

}

//- (void)setSelected:(BOOL)selected animated:(BOOL)animated
//{
//    [super setSelected:selected animated:animated];
//
//    if (selected) {
//        [self setAnimation];
//    }else{
//        [self closeAnimation];
//    }
//}


- (void)setAnimation0{


    self.bgImageView.image = [UIImage imageNamed:@"选中"];
    self.transform = CGAffineTransformMakeScale(1.2, 1.2);


//    [UIView animateWithDuration:0.2 animations:^{
//        self.bgImageView.image = [UIImage imageNamed:@"map_animation_selected"];
//        self.transform = CGAffineTransformMakeScale(1.2, 1.2);
//    } completion:^(BOOL finished) {
//
//    }];

    
}


- (void)setAnimation{


    [UIView animateWithDuration:0.2 animations:^{
        self.bgImageView.image = [UIImage imageNamed:@"选中"];
        self.transform = CGAffineTransformMakeScale(userScale, userScale);
    } completion:^(BOOL finished) {
        
    }];



   
    
}
- (void)closeAnimation{
    [UIView animateWithDuration:0.2 animations:^{
        self.bgImageView.image = [UIImage imageNamed:@"未选中"];
        self.transform = CGAffineTransformIdentity;
    } completion:^(BOOL finished) {
        
    }];
    
}

//- (UIImageView *)bgImageView{
//    if (_bgImageView == nil) {
//        _bgImageView = [[UIImageView alloc]initWithFrame:self.bounds];
//        _bgImageView.image = [UIImage imageNamed:@"map_animation"];
//    }
//    return _bgImageView;
//}
//
//
//- (UIImageView *)headImageView{
//    if (_headImageView == nil) {
//        _headImageView = [[UIImageView alloc]initWithFrame:self.bounds];//CGRectMake(5, 5, self.bounds.size.width - 10, self.bounds.size.width - 10)];
//
//    }
//    return _headImageView;
//}

@end
