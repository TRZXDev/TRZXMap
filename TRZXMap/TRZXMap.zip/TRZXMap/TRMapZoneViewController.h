//
//  TRMapZoneViewController.h
//  TRZX
//
//  Created by Rhino on 2016/12/23.
//  Copyright © 2016年 Tiancaila. All rights reserved.
//

#import "City.h"
@interface TRMapZoneViewController : UIViewController

@property (nonatomic,copy)void (^cityCallback)(City *city);


@end
