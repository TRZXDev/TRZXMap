//
//  MapUser.h
//  TRZX
//
//  Created by N年後 on 2017/1/4.
//  Copyright © 2017年 Tiancaila. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MapUser : NSObject
@property (nonatomic, copy) NSString *individualResume;
@property (nonatomic, copy) NSString *userId;

@property (nonatomic, copy) NSString *distance;
@property (nonatomic, copy) NSString *objId;


@property (nonatomic, copy) NSString *longitude;
@property (nonatomic, copy) NSString *latitude;
@property (nonatomic, copy) NSString *localLatitude;
@property (nonatomic, copy) NSString *locaLongitude;


@property (nonatomic, copy) NSString *isOnline;
@property (nonatomic, copy) NSString *photo;
@property (nonatomic, copy) NSString *userType;
@property (nonatomic, copy) NSString *sex;
@property (nonatomic, copy) NSString *type; // Resources("资源")  Requirement("需求")  Project("项目")
@property (nonatomic, copy) NSString *level; // district("区")  city("城市")
@property (nonatomic, copy) NSString *kcount;
@property (nonatomic, copy) NSDictionary *coordinate;



@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *distanceStr; // 距离
@property (nonatomic, copy) NSString *company; //
@property (nonatomic, copy) NSString *position; //

@property (nonatomic) NSInteger kdistance; // 距离

@property (nonatomic, copy) NSArray *stageList; // 阶段
@property (nonatomic, copy) NSArray *tradeList; // 领域







@end
